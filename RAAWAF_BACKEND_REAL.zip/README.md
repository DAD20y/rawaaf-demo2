# رواف - Backend الحقيقي - جاهز للإطلاق
Founder: Saud Al-Juhani - Hail - 0558098176

## الخطوات للتشغيل:
1- أنشئ مشروع Supabase مجاني supabase.com
2- شغل supabase/schema.sql في SQL Editor
3- فعل Auth Phone + Storage bucket "property-images"
4- npm install next.js @supabase/supabase-js
5- حط المفاتيح في .env
6- npm run dev

## المميزات المبنية:
- منع الحجز المزدوج (exclusion constraint)
- محفظة رقمية حقيقية
- تقييمات مرتبطة بحجز مكتمل فقط
- قفل ذكي API جاهز
- دفع Moyasar 1.5% (أرخص من جاذرن 2.8%)

## الواجهة الأمامية:
استخدم index.html السابق كـ frontend مؤقت واربطه بهذا الـ backend عبر fetch
