
// app/api/bookings/route.ts - منع الحجز المزدوج + محفظة
import { createClient } from '@supabase/supabase-js'

export async function POST(req: Request) {
  const { property_id, check_in, check_out, wallet_use } = await req.json()
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!)
  
  // 1. تحقق من التوفر
  const { data: conflict } = await supabase.from('bookings')
    .select('id').eq('property_id', property_id)
    .in('status',['paid','confirmed'])
    .or(`and(check_in.lte.${check_out},check_out.gte.${check_in})`)
  
  if (conflict?.length) return Response.json({error: 'محجوز في هذه الفترة'}, {status: 409})

  // 2. احسب السعر + 8% عمولة
  // 3. اخصم من المحفظة إن وجد
  // 4. أنشئ كود دخول
  // 5. ارسل واتساب https://wa.me/message/QDMJDN3ZRA5NG1

  return Response.json({ success: true, access_code: '7392#' })
}
