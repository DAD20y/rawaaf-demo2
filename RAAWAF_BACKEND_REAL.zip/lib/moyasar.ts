
// lib/moyasar.ts - دفع مدى و أبل باي 1.5% فقط
export async function createPayment(amount: number, bookingId: string) {
  const res = await fetch('https://api.moyasar.com/v1/payments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      amount, // halalas
      currency: 'SAR',
      description: `حجز رواف #${bookingId}`,
      source: { type: 'creditcard' },
      callback_url: `https://rawaaf.sa/api/callback/${bookingId}`
    })
  })
  return res.json()
}
