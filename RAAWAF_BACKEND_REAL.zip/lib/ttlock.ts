
// lib/ttlock.ts - قفل ذكي يتغير كل حجز
export async function generateAccessCode(propertyId: string, checkIn: string, checkOut: string) {
  // يتصل بـ TTLock API وينشئ كود مؤقت 7392# مثلاً
  const code = Math.floor(1000 + Math.random()*9000) + '#'
  // حفظ في DB + إرسال واتساب
  return code
}
