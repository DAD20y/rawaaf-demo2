import './globals.css'
export default function RootLayout({children}:{children:any}){return <html lang='ar' dir='rtl'><body className="bg-[#F8F7F4] font-['Tajawal']">{children}</body></html>}
