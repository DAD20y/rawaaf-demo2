
export default function Owner(){return <div className="p-8"><h1 className="text-3xl font-black">منصة الملاك</h1><p className="mt-4">5 خطوات: تسجيل + توثيق + إضافة وحدات + قفل ذكي 400 ر.س + تفعيل - عمولة 8% vs المنافس 18%</p><p className="mt-4">واتساب: https://wa.me/message/QDMJDN3ZRA5NG1 - 0558098176</p></div>}
