
'use client'
import { useState } from 'react'
export default function Home(){
 const [properties]=useState([
  {id:1,title:'شاليه الزيتون الفاخر',city:'حائل',price:600,img:'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800',rating:4.9},
  {id:2,title:'فيلا النخيل',city:'حائل',price:900,img:'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',rating:4.8},
  {id:3,title:'شقة الورود',city:'حائل',price:250,img:'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',rating:4.7},
 ])
 return (<div className="min-h-screen"><header className="bg-[#0A1931] text-white p-4 flex justify-between"><h1 className="text-2xl font-black"><span className="text-[#C9A86A]">رواف</span></h1><div className="flex gap-2"><span className="bg-[#C9A86A] px-4 py-2 rounded-full text-sm">8% vs المنافس 18%</span></div></header><div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">{properties.map(p=>(<div key={p.id} className="bg-white rounded-[24px] overflow-hidden shadow"><img src={p.img} className="h-56 w-full object-cover"/><div className="p-4"><h3 className="font-bold">{p.title}</h3><p className="text-gray-500">{p.city} • {p.rating}★</p><p className="font-black mt-2">{p.price} ر.س / ليلة</p><button className="mt-3 w-full bg-[#0A1931] text-white py-2 rounded-full">احجز - كود 7392#</button></div></div>))}</div><a href="https://wa.me/message/QDMJDN3ZRA5NG1" className="fixed bottom-6 left-6 bg-[#25D366] w-14 h-14 rounded-full flex items-center justify-center text-white text-2xl">💬</a></div>)
}
