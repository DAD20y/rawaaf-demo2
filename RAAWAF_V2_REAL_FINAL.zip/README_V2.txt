
رواف v2 - ربط حقيقي 100%
Founder: Saud Al-Juhani - 0558098176 - Hail
WhatsApp: https://wa.me/message/QDMJDN3ZRA5NG1

التشغيل:
1- index.html دبل كلك
2- فوق حط مفاتيح Supabase (supabase.com -> New Project -> Settings -> API)
3- اختبر الاتصال -> يصير اخضر
4- الان: رفع صور S3 + حجز يمنع المزدوج + دفع Moyasar + محفظة كلها حقيقية

للإنتاج:
npm install next @supabase/supabase-js
حط الكود في pages/api
ارفع على Vercel

عمولة 8% vs المنافس الآخر 18%
