
export async function POST(req:Request){
 const {property_id, check_in, check_out} = await req.json()
 const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!)
 const {data: conflict} = await supabase.from('bookings').select('id').eq('property_id', property_id).in('status',['paid','confirmed']).or(`and(check_in.lte.${check_out},check_out.gte.${check_in})`)
 if(conflict?.length) return Response.json({error:'محجوز'}, {status:409})
 const code = Math.floor(1000+Math.random()*9000)+'#'
 return Response.json({success:true, access_code: code})
}
