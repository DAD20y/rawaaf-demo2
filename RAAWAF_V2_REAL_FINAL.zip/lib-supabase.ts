
import { createClient } from '@supabase/supabase-js'
export const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)
// Usage:
// const {data} = await supabase.from('properties').select('*').eq('status','approved')
// Upload: await supabase.storage.from('property-images').upload(name, file)
