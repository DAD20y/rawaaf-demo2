
export async function createPayment(amount:number, bookingId:string){
 const res = await fetch('https://api.moyasar.com/v1/payments',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body: JSON.stringify({amount: amount*100, currency:'SAR', description:`رواف #${bookingId}`, source:{type:'creditcard'}, callback_url:`https://rawaaf.sa/api/callback/${bookingId}`})
 })
 return res.json()
}
