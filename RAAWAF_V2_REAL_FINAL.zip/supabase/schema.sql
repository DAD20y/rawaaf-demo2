
-- Rawaaf DB Schema - Production Ready
-- Founder: Saud Al-Juhani - Hail

-- Enable extensions
create extension if not exists "uuid-ossp";

-- Users (extends auth.users)
create table public.profiles (
  id uuid primary key references auth.users(id),
  phone text unique not null,
  full_name text,
  role text check (role in ('client','owner','admin')) default 'client',
  wallet_balance integer default 0, -- in halalas
  points integer default 0,
  level text default 'bronze',
  avatar_url text,
  created_at timestamp default now()
);

-- Properties
create table public.properties (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid references public.profiles(id) not null,
  type text check (type in ('chalet','villa','apartment','farm')) not null,
  title text not null,
  city text not null,
  address text,
  lat float,
  lng float,
  bedrooms int,
  bathrooms int,
  max_guests int,
  area_sqm int,
  amenities text[] default '{}',
  price_per_night integer not null, -- halalas
  price_weekend integer,
  images text[] default '{}', -- S3 URLs
  status text default 'pending' check (status in ('pending','approved','rejected')),
  smart_lock_id text,
  rating_avg float default 0,
  rating_count int default 0,
  created_at timestamp default now()
);

-- Bookings
create table public.bookings (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid references public.properties(id) not null,
  client_id uuid references public.profiles(id) not null,
  check_in date not null,
  check_out date not null,
  guests int,
  total_price integer not null,
  cleaning_fee integer default 15000,
  service_fee integer, -- 8%
  status text default 'pending' check (status in ('pending','paid','confirmed','completed','cancelled')),
  payment_method text,
  access_code text, -- 7392#
  wallet_used integer default 0,
  points_earned int default 0,
  created_at timestamp default now(),
  constraint no_overlap exclude using gist (property_id with =, daterange(check_in, check_out) with &&) where (status in ('paid','confirmed'))
);

-- Reviews
create table public.reviews (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid references public.properties(id),
  booking_id uuid references public.bookings(id) unique,
  client_id uuid references public.profiles(id),
  rating int check (rating between 1 and 5),
  comment text,
  images text[],
  owner_reply text,
  created_at timestamp default now()
);

-- Wallet Transactions
create table public.wallet_transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id),
  type text check (type in ('topup','booking','refund','cashback','payout')),
  amount integer not null,
  balance_after integer,
  reference_id uuid,
  created_at timestamp default now()
);

-- RLS
alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.bookings enable row level security;
alter table public.reviews enable row level security;
alter table public.wallet_transactions enable row level security;

create policy "public read approved properties" on public.properties for select using (status='approved');
create policy "owners manage own" on public.properties for all using (owner_id = auth.uid());
create policy "clients read own bookings" on public.bookings for select using (client_id = auth.uid() or property_id in (select id from properties where owner_id = auth.uid()));
